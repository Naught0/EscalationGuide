function showMenu() {
    document.getElementById("sidebar-menu").classList.toggle("show");
    document.getElementById("menu").classList.toggle("is-active");
}